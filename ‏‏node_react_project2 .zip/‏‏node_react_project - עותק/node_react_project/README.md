# node_react_project
basic project, to use react,node, and mysql
<<<<<<< HEAD
npm start
=======

1. download
2. un-zip
3. open in vs-code
4. run in the terminal the following command:
  cd server
  node src/app
7. r
>>>>>>> aaee8af71b33830d77f337052150f0a0d61d216a
