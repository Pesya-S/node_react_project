import React, { useEffect, useState, useContext } from 'react';
import userService from '../../services/userService';


export default function ProductsList(props) {
    

    useEffect(() => //initial
    {
       
        // eslint-disable-next-line
    }, []);



    return (
        <>
            produccts list
        </>
    )
}