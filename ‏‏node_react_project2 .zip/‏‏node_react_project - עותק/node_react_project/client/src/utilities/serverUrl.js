const serverUrl = 'http://localhost:8080'
export default serverUrl;
