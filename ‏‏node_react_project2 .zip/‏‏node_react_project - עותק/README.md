# node_react_project
basic project, to use react,node, and mysql

1. download
2. un-zip
3. open in vs-code
4. run in the terminal the following command:
  cd server
  node src/app
7. r
r 8
